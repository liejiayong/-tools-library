<?php
/**
* 配置参数
*/
	class Config{

        static $AppId = "155426970880859";//测试参数，仅供测试使用；
        static $Key = "ermKvsfEvLsJ71SxiBoc282JqDYEAuUT";//测试key//参数获取指引：https://blog.csdn.net/bloodyer/article/details/78669282
		
		static $timezone="Asia/Shanghai";
        static $trade_time_out="3600";
        static $front_notify_url="http://notify/fnotify.php";
        static $back_notify_url="http://notify/bnotify.php";

        const TRADE_URL="https://pay.ipaynow.cn";//交易接口地址



        const TRADE_FUNCODE="WP001";
        const QUERY_FUNCODE="MQ002";
        const NOTIFY_FUNCODE="N001";
        const FRONT_NOTIFY_FUNCODE="N002";
        const TRADE_TYPE="05";
        const TRADE_CURRENCYTYPE="156";
        const TRADE_CHARSET="UTF-8";
        const TRADE_DEVICE_TYPE="20";
        const TRADE_SIGN_TYPE="MD5";
        const TRADE_QSTRING_EQUAL="=";
        const TRADE_QSTRING_SPLIT="&";
        const TRADE_FUNCODE_KEY="funcode";
        const TRADE_DEVICETYPE_KEY="deviceType";
        const TRADE_SIGNTYPE_KEY="mhtSignType";
        const TRADE_SIGNATURE_KEY="mhtSignature";
        const SIGNATURE_KEY="signature";
        const SIGNTYPE_KEY="signType";
        const VERIFY_HTTPS_CERT=false;
    }