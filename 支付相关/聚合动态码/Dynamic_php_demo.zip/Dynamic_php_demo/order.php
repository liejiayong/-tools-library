<?php
	require_once './config/config.php';
	require_once './controller/signaTure.php';
	require_once './controller/postRequest.php';
	require_once './utils/phpqrcode.php';
    require_once './utils/Log.php';

$errorLevel = "L";

$size = "4";
/**
 * 
 * 消费接口
 * 用于对支付信息进行重组和签名，并将请求发往现在支付
 * 
 */

	$req=array();
	$req["funcode"]           = Config::TRADE_FUNCODE;
	$req["version"]           = "1.0.0";
	$req["appId"]             = config::$AppId;
	$req["mhtOrderNo"]        = date("YmdHis").rand(10000,99999);
	$req["mhtOrderName"]      = "自定义";
	$req["mhtCurrencyType"]   = Config::TRADE_CURRENCYTYPE;
	$req["mhtOrderAmt"]       = "10";
	$req["mhtOrderDetail"]    = "测试";
	$req["mhtOrderTimeOut"]   = Config::$trade_time_out;
	$req["mhtOrderStartTime"] = date("YmdHis");
	$req["notifyUrl"]         = Config::$back_notify_url;
	$req["mhtCharset"]        = Config::TRADE_CHARSET;
	$req["outputType"]        = "1";
	$req["deviceType"]        = Config::TRADE_DEVICE_TYPE;
	$req["frontNotifyUrl"]    = Config::$front_notify_url;
	$req["payChannelType"]    = "13";
	$req["mhtLimitPay"]       =  "0";//不限制卡类型
    $req["mhtOrderType"]      = Config::TRADE_TYPE;
    $req["mhtSignType"]       = Config::TRADE_SIGN_TYPE;

	$info = new SignaTure;
	$req_str = $info -> getToStr($req, config::$Key);

	$post = new PostRequest;
	$res = $post -> post(Config::TRADE_URL, $req_str);

//打印请求数据
    Log::outLog("请求内容：",$req_str);

	$code = (bool)stripos($res, '&tn=');
	if($code) {
	$arr = explode('&', $res);
	$gettn = '';
	foreach($arr as $v) {
		$tn = explode('=', $v);
		if($tn[0] == 'tn'){
			$gettn = $tn[1];
		}
	}
	//echo '<返回二维码串：'.urldecode($gettn).'>';

        $url=urldecode($gettn);

    echo QRcode::png($url,false,$errorLevel,$size);
} else {
	echo $res;
}
